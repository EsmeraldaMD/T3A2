
package t3a2;
import java.util.Scanner;
/**
 *
 * @author esmer
 */
public class Main {

    
    public static void main(String[] args) {
       calculos();
    }
    public static void calculos(){
    Scanner obj=new Scanner(System.in);
    T3A2 ho=new T3A2();
    
        System.out.println("HORAS TRANSCURRIDAS"
                + "\nDias de la semana:"
                + "\n1.-Lunes"
                + "\n2.-Martes"
                + "\n3.-Miercoles"
                + "\n4.-Jueves"
                + "\n5.-Viernes"
                + "\n6.-Sabado"
                + "\n7.-Domingo");
    
        System.out.println("Ingrese el numero del primer dia ");
        int d1=obj.nextInt();
        ho.setD1(d1);
        
        System.out.println("Hora de inicio de ese dia (considere el formato de 24 horas): ");
        int h1=obj.nextInt();
        ho.setH1(h1);
        
        System.out.println("Ingrese el numero del segundo dia ");
        int d2=obj.nextInt();
        ho.setD2(d2);
        
        System.out.println("Hora final de ese dia (considere el formato de 24 horas): ");
        int h2=obj.nextInt();
        ho.setH2(h2);
        ho.getR();
        if (d1<=7 & d1>=1){
            if(d2<=7 & d2>=1){
                if(d1<=d2){
                   System.out.println(ho.toString());
                }
                else{
                    System.out.println("El dia 2 no es posterior al dia 1");
                }
            }
            else{
                System.out.println("El numero del dia 2 ingresado no es válido");
            }
        }
        else{
             System.out.println("El numero del dia 1 ingresado no es válido");
        }
        
    }
}
