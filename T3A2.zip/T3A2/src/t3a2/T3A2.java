
package t3a2;

/**
 *
 * @author esmer
 */
public class T3A2 {
    private int d1;
    private int d2;
    private int h1;
    private int h2;
    private int r;

    public T3A2() {
    }

    public T3A2(int d1, int d2, int h1, int h2, int r) {
        this.d1 = d1;
        this.d2 = d2;
        this.h1 = h1;
        this.h2 = h2;
        this.r = r;
    }

    public int getD1() {
        return d1;
    }

    public void setD1(int d1) {
        this.d1 = d1;
    }

    public int getD2() {
        return d2;
    }

    public void setD2(int d2) {
        this.d2 = d2;
    }

    public int getH1() {
        return h1;
    }

    public void setH1(int h1) {
        this.h1 = h1;
    }

    public int getH2() {
        return h2;
    }

    public void setH2(int h2) {
        this.h2 = h2;
    }

    public int getR() {
                    r=d1+1;
                    r=d2-r;
                    r=r*24;
                    r=r+(24-h1)+h2;
                
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }
    @Override
    public String toString() {
        String mensaje = "El numero de horas entre el dia "+d1+" a las "+h1+" horas y el dia "+d2+" a las "+h2+" horas es de: \n" + r+" horas";
        return mensaje;
    }
    }
